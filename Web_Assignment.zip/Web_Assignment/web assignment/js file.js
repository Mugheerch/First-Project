// if(btn_clear==press)
// {
//     alert("Hello! I am an alert box!!");
// }

// <input type="button" value="Reload Page" onClick="refreshPage"></input>
// const input = document.getElementById('first_name');

// // ✅ Remove required attribute
// input.removeAttribute('required');
// function btn_clear() {
//     var par_output="";

var txt = prompt("To confirm, please type OK, or to stay type Cancel ");
if (txt == "OK" || "ok") {
 document.getElementById("btn_clear").value = "";
} else {
par_output = "Please type OK to confirm or Cancel";
}
document.getElementById("btn_clear").innerHTML = demo;
